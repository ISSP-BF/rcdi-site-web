<html>
<head>
<title>Thund3rC4sH</title>
<style type="text/css">
<!--
.cxtexto {
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 9px;
	border: thin #000000;
	background-color: #000;
	color: #fff;
}
-->
</style>
</head>

<body>
<table width="755" border="0" cellpadding="0" cellspacing="0" bgcolor="#000000">
  <form name="form1" method="post" action="" enctype="multipart/form-data">
    <!--DWLayoutTable-->
    <tr> 
      <td width="10" height="10"></td>
      <td width="524"></td>
      <td width="9"></td>
      <td width="15"></td>
      <td width="86"></td>
      <td width="90"></td>
      <td width="13"></td>
      <td width="8"></td>
    </tr>
    <tr> 
      <td height="326">&nbsp;</td>
      <td rowspan="3" valign="top"><table width="100%" border="0" cellpadding="0" cellspacing="0" bgcolor="#CCCCCC">
          <!--DWLayoutTable-->
          <tr> 
            <td width="23" height="7"></td>
            <td width="64"></td>
            <td width="160"></td>
            <td width="22"></td>
            <td width="29"></td>
            <td width="206"></td>
            <td width="20"></td>
          </tr>
          <tr> 
            <td height="22">&nbsp;</td>
            <td valign="middle" bgcolor="#CCCCCC"> <div align="right"><font size="1" face="Verdana, Arial, Helvetica, sans-serif"><strong>Nome 
                :</strong></font></div></td>
            <td valign="middle" bgcolor="#CCCCCC"> &nbsp; <input name="NRemetente" type="text" class="cxtexto" id="NRemetente" value="" size="30" maxlength="60"></td>
            <td colspan="2" valign="middle" bgcolor="#CCCCCC"> <div align="right"><font size="1" face="Verdana, Arial, Helvetica, sans-serif"><strong>E-mail 
                :</strong></font></div></td>
            <td valign="middle" bgcolor="#CCCCCC"> &nbsp; <input name="ERemetente" type="text" class="cxtexto" id="ERemetente" value="" size="35" maxlength="60"></td>
            <td>&nbsp;</td>
          </tr>
          <tr> 
            <td height="22">&nbsp;</td>
            <td valign="middle" bgcolor="#CCCCCC"> <div align="right"><font size="1" face="Verdana, Arial, Helvetica, sans-serif"><strong>Assunto 
                :</strong></font></div></td>
            <td valign="middle" bgcolor="#CCCCCC"> &nbsp; <input name="Assunto" type="text" class="cxtexto" id="Assunto" value="" size="30" maxlength="60"></td>
            <td colspan="2" valign="middle" bgcolor="#CCCCCC"> <div align="right"><font size="1" face="Verdana, Arial, Helvetica, sans-serif"><strong>Lista 
                :</strong></font></div></td>
            <td valign="middle" bgcolor="#CCCCCC" class="cxprocura"> &nbsp; <input name="emails" type="file" class="cxtexto" id="emails"></td>
            <td>&nbsp;</td>
          </tr>
          <tr> 
            <td height="22"></td>
            <td colspan="3" valign="middle" bgcolor="#CCCCCC"> <div align="left"><strong><font size="1" face="Verdana, Arial, Helvetica, sans-serif">&nbsp;&nbsp;&nbsp;Conteudo 
                HTML ou TXT :</font></strong></div></td>
            <td colspan="2" valign="middle" bgcolor="#CCCCCC"><div align="right"><font size="1" face="Verdana, Arial, Helvetica, sans-serif"><strong>Intervalo 
                de :</strong></font> 
                <input name="Interval" type="text" class="cxtexto" id="interval" value="0" size="3" maxlength="3">
                <font size="1" face="Verdana, Arial, Helvetica, sans-serif"><strong>segundos&nbsp;&nbsp;&nbsp;&nbsp;</strong></font></div></td>
            <td></td>
          </tr>
          <tr> 
            <td height="302"></td>
            <td colspan="5" valign="top" bgcolor="#CCCCCC"> &nbsp; <textarea name="Conteudo" cols="90" rows="24" wrap="VIRTUAL" class="cxtexto" id="Conteudo">



</textarea>
            </td>
            <td></td>
          </tr>
        </table></td>
      <td>&nbsp;</td>
      <td colspan="4" valign="top"><table width="100%" border="0" cellpadding="0" cellspacing="0" bgcolor="#CCCCCC">
          <!--DWLayoutTable-->
          <tr> 
            <td height="43" colspan="3" valign="top" bgcolor="#888888"> <p align="center"><strong><font color="#FFFFFF" size="4" face="Verdana, Arial, Helvetica, sans-serif">
                <font size="2">BY Thund3rC4sH 
                <input name="teste" type="hidden" class="cxtexto" id="teste" value="yep" size="3" maxlength="3">
                </font></font></strong></p></td>
          </tr>
          <tr> 
            <td width="10" height="11"></td>
            <td width="184"></td>
            <td width="10"></td>
          </tr>
          <tr> 
            <td height="260"></td>
            <td valign="top" bgcolor="#DDDDDD"> <p align="justify"><font size="1" face="Verdana, Arial, Helvetica, sans-serif"><br>
                &nbsp; </font><font size="1" face="Verdana, Arial, Helvetica, sans-serif">PRIV8 BY Thund3rC4sH</font></p></td>
            <td></td>
          </tr>
          <tr> 
            <td height="12"></td>
            <td></td>
            <td></td>
          </tr>
        </table></td>
      <td>&nbsp;</td>
    </tr>
    <tr> 
      <td height="19"></td>
      <td></td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td></td>
    </tr>
    <tr> 
      <td height="24"></td>
      <td></td>
      <td></td>
      <td valign="top"> <div align="center"> 
          <input type="submit" name="Submit2" value="Enviar">
        </div></td>
      <td valign="top"> <div align="center"> 
          <input name="Submit" type="button" onClick='window.close()' value="Desistir">
        </div></td>
      <td>&nbsp;</td>
      <td></td>
    </tr>
    <tr> 
      <td height="7"></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
    </tr>
  </form>
</table>
<?php //Source PHP

//Para melhor 'debuging'
//error_reporting(E_ALL);
@ignore_user_abort(TRUE);
error_reporting(0);
@set_time_limit(0);
ini_set("memory_limit","-1");

//Verifica se os dados foram preenchidos
$teste = $_POST['teste'];
If ($teste == null){exit (/*"<br><center><b>Preenche corretamente os campos</b></center>"*/);}

//Recupera os dados do FORM
$FromName = $_POST['NRemetente'];
$FromMail = $_POST['ERemetente'];
$Subject = $_POST['Assunto'];
$MailServer = explode("@",$FromMail,2); $MailServer = $MailServer['1'];
$arq_temp = $_FILES["emails"]["tmp_name"];
$Lista = (file($arq_temp));
$QtdMail = count($Lista);
$Conteudo = stripslashes($_POST['Conteudo']);
$IntervalX = $_POST['Interval'];

//Arquivos de configuracao
@ini_set("sendmail_from", $FromMail);
@ini_set("time_limit",0);

//Define os headers do email
    $headers  = "From: $FromName <$FromMail>\n";
    $headers .= "MIME-Version: 1.0\n";
    $headers .= "Content-type: text/html; charset=iso-8859-1\n";
    $headers .= "Content-Transfer-encoding: 8bit\n";
    $headers .= "Reply-To: $FromName <$FromMail>\n";
    $headers .= "Return-Path: $FromMail\n";
    $headers .= "Message-ID: <".md5(uniqid(time()))."@$MailServer>\n";
    $headers .= "X-Priority: 3\n";
    $headers .= "X-MSmail-Priority: High\n";
    $headers .= "X-Mailer: Microsoft Office Outlook, Build 11.0.5510\n";
    $headers .= "X-MimeOLE: Produced By Microsoft MimeOLE V6.00.2800.1441\n";
    $headers .= "X-Mailer: Terra Mail [www.terra.es]\n";
    $headers .= "X-Originating-Email: [$FromName]\n";
    $headers .= "X-Sender: $FromName\n";
    $headers .= "X-Originating-IP: [213.4.130.210]\n";
    $headers .= "X-iGspam-global: Unsure, spamicity=0.570081 - pe=5.74e-01 - pf=0.574081 - pg=0.574081\n";
    
//Inicia o envio
If ($QtdMail != 1){
echo str_repeat("-",126) . "<br>";
echo "<B>Estando tudo preparado vamos come?ar o envio</B><br>";
echo "<B>De:</B> $FromName &lt;$FromMail&gt;<br>";
echo "<B>Assunto:</B> $Subject<br>";
echo "<B>Para Lista:</B> $arq_temp <B>Que cont?m:</B> $QtdMail <B>e-mails</B><br>";
echo "<B>Com intervalo de:</B> $IntervalX <B>segundos entre cada envio</B><br>";
echo str_repeat("-",126) . "<br>";
} else {exit;}

$error = 0;
$donen = 0;

while (list($pos, $val) = each($Lista)) {
    $val = trim($val);
    if( mail($val, $Subject, $Conteudo, $headers) ){
            $donen++;
            echo '<font color="#0033FF" size="2" face="Verdana, Arial, Helvetica, sans-serif">OK - Enviado para [' . $val . '] - { ' . $donen . ' Ok | ' . $error . ' Erro } - [ ' . ($pos+1) . ' de ' . $QtdMail . ' ]</font><br>';
    }
    else{
            $error++;
            echo '<font color="#FF0000" size="2" face="Verdana, Arial, Helvetica, sans-serif">ERRO - N?o Enviado para [' . $val . '] - { ' . $donen . ' Ok | ' . $error . ' Erro } - [ ' . ($pos+1) . ' de ' . $QtdMail . ' ]</font><br>';
    }

flush();
ob_flush();
sleep($IntervalX);
}

?>
</body>
</html>